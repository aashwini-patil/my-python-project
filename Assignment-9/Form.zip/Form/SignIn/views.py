from django.shortcuts import render
from SignIn.forms import ContactForm
# Create your views here.
def home(request):
    # return render(request, 'home.html')
    con = ContactForm()
    return render(request, 'home.html', {'form': con})

def login(request):
    return render(request, 'login.html')